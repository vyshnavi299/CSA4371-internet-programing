<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $db_host = "localhost";     // Replace with your database host
    $db_user = "root";          // Replace with your database username
    $db_password = "";           // Replace with your database password
    $db_name = "hotel";          // Replace with your database name

    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $name = $conn->real_escape_string($_POST["name"]);
    $checkin = $conn->real_escape_string($_POST["checkin"]);
    $checkout = $conn->real_escape_string($_POST["checkout"]);
    $roomtype = $conn->real_escape_string($_POST["room-type"]);

    // Insert the booking into the database
    $sql = "INSERT INTO bookings (`name`, `checkin`, `checkout`, `roomtype`) VALUES ('$name', '$checkin', '$checkout', '$roomtype')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Booking is successful.</p>";
    } else {
        echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }

    // Close the database connection
    $conn->close();
} else {
    // If the request method is not POST, do nothing
    echo "<p>Invalid request.</p>";
}
?>
